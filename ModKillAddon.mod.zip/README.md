# ModKillAddon

给 **Degrees of Lewdity**（「欲都孤儿」，0.5.12.13 简中）添加**击杀机制**的 ModLoader 模组。

让 NPC 真正可杀，且死了就真死了：**138 个无名敌人入口**覆盖几乎所有战斗；**6 位具名 NPC**（贝利 / 惠特尼 / 伊甸 / 黑狼 / 格威岚 / Avery）死后剧情线整体改写。另有「走开」等便利改动。

> **仅限 18 岁以上使用。**

---

## 安装

从 [Releases](https://github.com/qwe2695538371/ModKillAddon/releases) 下载 `ModKillAddon.mod.zip`，在 Mod 管理器里导入并重启游戏。

| 依赖 | 版本约束 |
|---|---|
| ModLoader | `^2.0.0` |
| ModI18N | `>=1.0.1a` |
| 游戏本体 | `=0.5.12.13`（**精确匹配，换版本即失效**） |

## 自动更新

游戏启动时会自动检查云端版本，有新版会弹窗，点一下即可自动更新。

发版流程（改版本 → 构建 → 传 zip + version.json → 发 Release）见
`知识库/06-杀戮接入实战/更新检查机制（GitHub Release）.md`。

---

## 版权与许可

本模组是 **CC BY-NC-SA 4.0** 授权的**演绎作品**，基于以下作品修改：

| 作品 | 作者 / 项目 | 授权 |
|---|---|---|
| *Degrees of Lewdity* | **Vrelnir** — https://gitgud.io/Vrelnir/degrees-of-lewdity | CC BY-NC-SA 4.0 |
| 中文本地化「**欲都孤儿**」 | Eltirosto 及社区贡献者 — https://github.com/Eltirosto/Degrees-of-Lewdity-Chinese-Localization | CC BY-NC-SA 4.0 |
| **ModKillAddon**（本模组） | qwe2695538371 — https://github.com/qwe2695538371/ModKillAddon | CC BY-NC-SA 4.0 |

### 修改说明

本模组**复制并修改了原作与汉化版的大量游戏文本**：

- **修改**：`s_*` 页面 —— 逐字复制原版 passage 后，在其基础上插入或改写「击杀」相关内容
- **新增**：新增 passage、JavaScript、界面文字（均为本模组原创）

原作与汉化版的其余内容未作改动。

### 许可条款

你可自由**共享**（复制、发行）与**演绎**（修改、转换、基于本作品创作）本作品，惟须遵守：

- **署名** —— 注明上述原作者、汉化项目与本模组作者，并说明是否作了修改
- **非商业性使用** —— 不得用于商业目的
- **相同方式共享** —— 若你基于本作品创作，必须以相同协议分发你的贡献

**不得**对本作品附加任何额外限制（包括技术措施）。

协议全文见 [LICENSE](LICENSE)，或 https://creativecommons.org/licenses/by-nc-sa/4.0/legalcode.zh-hans

### 免责声明

本作品按「现状」提供，不附带任何形式的担保，作者不对使用本作品造成的任何损失负责。

*Degrees of Lewdity* 及本模组均为面向成年人的虚构作品，**仅限 18 岁以上**使用。
